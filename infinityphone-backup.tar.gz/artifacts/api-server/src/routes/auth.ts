import { Router } from "express";
import { AdminLoginBody, AdminLoginResponse, AdminLogoutResponse, GetAuthStatusResponse } from "@workspace/api-zod";

const router: import("express").IRouter = Router();

router.get("/auth/me", (req, res): void => {
  const session = req.session as { adminAuthenticated?: boolean };
  res.json(GetAuthStatusResponse.parse({ authenticated: !!session.adminAuthenticated }));
});

router.post("/auth/login", (req, res): void => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const adminPassword = process.env.ADMIN_PASSWORD ?? "";
  const usandoPadrao = !adminPassword;
  const senhaEfetiva = adminPassword || "infinityphone2024";
  const adminUsername = process.env.ADMIN_USERNAME || "admin";

  if (usandoPadrao) {
    req.log.warn("USANDO SENHA PADRAO. Defina ADMIN_PASSWORD nas variaveis de ambiente para maior seguranca.");
  }

  const usernameOk = parsed.data.username === adminUsername;
  const passwordOk = parsed.data.password === senhaEfetiva;

  if (!usernameOk || !passwordOk) {
    res.status(401).json({ error: "Usuario ou senha incorretos" });
    return;
  }

  const session = req.session as { adminAuthenticated?: boolean };
  session.adminAuthenticated = true;
  res.json(AdminLoginResponse.parse({ authenticated: true }));
});

router.post("/auth/logout", (req, res): void => {
  req.session.destroy(() => {
    res.json(AdminLogoutResponse.parse({ authenticated: false }));
  });
});

export default router;
